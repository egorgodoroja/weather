import 'package:flutter/material.dart';
import "package:flutter_bloc/flutter_bloc.dart";
import "package:lucide_icons/lucide_icons.dart";

import "bloc.dart";

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget{
  const MyApp({super.key});
  @override
  Widget build(BuildContext context)=>MultiBlocProvider(
    providers: [
      BlocProvider(
        create: (_)=>CityBloc()..add(LoadCityFromPrefs())
      ),
      BlocProvider(
        create: (_)=>WeatherBloc()
      )
    ],
    child: const App()
  );
}

class App extends StatelessWidget{
  const App({super.key});
  @override
  Widget build(BuildContext context){
    return MaterialApp(
      theme: ThemeData(
        scaffoldBackgroundColor: Color(0xFF1976D2)
      ),
      home: const Home()
    );
  }
}

class Home extends StatefulWidget{
  const Home({super.key});
  @override
  HomeState createState()=>HomeState();
}

class HomeState extends State<Home>{
  final controller = TextEditingController();
  @override
  Widget build(BuildContext context){
    return Scaffold(
      body: Stack(
        alignment: Alignment.center,
        children: [
          BlocBuilder<CityBloc, CityState>(
            builder: (context, state){
              if(state is CityExists){
                if(state.fetch){
                  context.read<WeatherBloc>().add(LoadWeather(state.city));
                  return Positioned(
                    top: state.topAlign,
                    child: Text(state.city, style: TextStyle(fontWeight: FontWeight.w800, fontSize: 30, fontFamily: "Geologica", color: Colors.white))
                  );
                }
                if(state is NoCity){
                  return Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      TextField(
                        controller: controller,
                        decoration: InputDecoration(
                          hintText: "Название города",
                          hintStyle: TextStyle(
                            color: Colors.white.withOpacity(0.8),
                            fontFamily: "Geologica",
                            fontWeight: FontWeight.w600,
                            fontSize: 18
                          ),
                          border: InputBorder.none,
                          focusedBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white, width: 2)),
                          enabledBorder: UnderlineInputBorder(borderSide: BorderSide(color: Colors.white, width: 2))
                        ),
                        style: TextStyle(
                          color: Colors.white,
                          fontFamily: "Geologica",
                          fontWeight: FontWeight.w800,
                          fontSize: 18
                        ),
                        cursorColor: Colors.white,
                      ),
                      SizedBox(width: 3),
                      IconButton(
                        style: IconButton.styleFrom(
                          backgroundColor: Colors.white,
                        ),
                        onPressed: (){
                          if(controller.text.length>3){
                            context.read<CityBloc>().add(InputCityManually(controller.text));
                          }
                        },
                        icon: Icon(LucideIcons.arrowRight, color: Colors.black)
                      )
                    ]
                  );
                }
              }
              return Container();
            }
          ),
          BlocBuilder<WeatherBloc, WeatherState>(
            builder: (context, state){
              if(state is WeatherLoaded){
                return appearence(
                  child: Column(
                    children: [
                      Text(
                        "${state.weatherData.temperature}°С",
                        style: TextStyle(
                          fontFamily: "Geologica",
                          fontSize: 30,
                          color: Colors.white,
                          fontWeight: FontWeight.w800
                        ),
                        textAlign: TextAlign.center,
                      ),
                      SizedBox(height: 20),
                      Text(
                        state.weatherData.weatherDescription,
                        style: TextStyle(
                          fontFamily: "Geologica",
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                          color: Colors.white
                        ),
                        textAlign: TextAlign.center,
                      )
                    ]
                  ),
                );
              }
              if(state is FetchWeatherError){
                return Text(
                  "Ooops! Failed to Load Weather!",
                  style: TextStyle(
                    fontSize: 30,
                    fontWeight: FontWeight.w800,
                    color: Colors.white,
                    fontFamily: "Geologica"
                  ),
                  textAlign: TextAlign.center,
                );
              }
              return Container();
            }
          )
        ]
      )
    );
  }
  Widget appearence({required Widget child}){
    return FutureBuilder<bool>(
      future: Future.delayed(Duration(milliseconds: 200), ()=>true),
      builder: (context, snapshot){
        bool opacity = snapshot.data ?? false;
        return AnimatedOpacity(
          opacity: opacity ? 1 : 0,
          duration: Duration(milliseconds: 500),
          child: child
        );
      },
    );
  }
}

