import "package:http/http.dart" as http;
import "dart:convert";

class WeatherData{
  final double temperature;
  final String weatherDescription;
  WeatherData(this.temperature, this.weatherDescription);
  static WeatherData fromJson(Map<String, dynamic> json){
    return WeatherData(json["current"]["temp_c"], json["current"]["condition"]["text"]);
  }
}

String apiKey = "2284af32414e4b968e9144214250504";

Future<WeatherData> fetchCurrentWeather(String cityName)async{
  Uri url = Uri.parse("http://api.weatherapi.com/v1/current.json?q=$cityName");
  final headers = {
    "key":apiKey
  };
  try{
    final res = await http.get(url, headers: headers);
    if(res.statusCode!=200){
      return Future.error("Invalid status code ${res.statusCode}");
    }
    return WeatherData.fromJson(jsonDecode(res.body));
  }catch(e){
    return Future.error("$e");
  }
}

